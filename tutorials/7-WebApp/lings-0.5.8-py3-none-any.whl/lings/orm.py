# -*- coding:utf-8 --*--
import re
from flask import jsonify
import pickle
from datetime import datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
import sqlalchemy
from sqlalchemy import func
from collections import OrderedDict
from flask_sqlalchemy.model import Model as SQLModel


class ORM(SQLAlchemy):
    def __init__(self):
        self.extra_db_uri = dict()
        Model.db = self
        super(ORM, self).__init__(model_class=Model)
        self.db_uri = None
        self.debug = False
        self.app = None
        self.triggers = {
            'before_insert': {},
            'after_insert': {},
            'before_delete': {},
            'after_delete': {},
            'before_update': {},
            'after_update': {},
        }

    def bind_db(self, bind_key):
        self.Model.__bind_key__ = bind_key

    def init_app(self, app):
        self.app = app
        self.debug = app.config['DEBUG']
        # uri = 'sqlite:///' + os.path.join(working_path, 'Maintenance.db')
        # self.app.config['SQLALCHEMY_DATABASE_URI'] = self.db_uri
        # self.app.config['SQLALCHEMY_BINDS'] = self.extra_db_uri
        # self.app.config['SQLALCHEMY_POOL_SIZE'] = 5
        # self.app.config['SQLALCHEMY_POOL_TIMEOUT'] = 20
        # self.app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = self.debug
        # self.app.config['SQLALCHEMY_ECHO'] = self.debug
        super(ORM, self).init_app(self.app)

    def max(self, table_field):
        return self.db.session.query(func.max(table_field)).scalar()

    @staticmethod
    def array2dict(obj_list):
        l = []
        for i in obj_list:
            l.append(i.to_dict())
        return l

    @staticmethod
    def array2json(obj_list):
        return jsonify(ORM.array2dict(obj_list))

    @staticmethod
    def str2datetime(s):
        if s is None:
            return s
        d = map(lambda x: int(x), re.findall('\d+', s))
        d = datetime(*d)
        if s.endswith('Z'):
            d += timedelta(hours=8)
        return d

    @staticmethod
    def rows2dict(rows):
        data = []
        col_names = rows.keys()
        for row in rows.fetchall():
            col = OrderedDict()
            i = 1
            for v in row:
                if isinstance(v, bytes):
                    v = pickle.loads(v)
                col[col_names[i - 1]] = v  # if isinstance(v, unicode) else str(v).decode(conn_json['coding'])
                i += 1
            data.append(col)
        return data

    @staticmethod
    def rows2json(rows):
        return jsonify(ORM.rows2dict(rows))

    @staticmethod
    def to_dict(objs):
        if isinstance(objs, list):
            return ORM.array2dict(objs)
        else:
            return ORM.rows2dict(objs)

    @staticmethod
    def to_json(objs):
        if isinstance(objs, list):
            return ORM.array2json(objs)
        else:
            return ORM.rows2json(objs)

    @staticmethod
    def paginate(rows, page, pagesize):
        '''
        cursor paginate dict data
        :param rows: cursor return by sqlalchemy execute
        :param page:
        :param pagesize:
        :return:
        '''
        for i in range((page - 1) * pagesize):
            rows.next()
        data = []
        col_names = rows.keys()
        for row in rows.fetchmany(pagesize):
            col = OrderedDict()
            i = 1
            for v in row:
                col[col_names[i - 1]] = v  # if isinstance(v, unicode) else str(v).decode(conn_json['coding'])
                i += 1
            data.append(col)
        return data

    def trigger(self, event, model):
        def wapper(func):
            if event not in self.triggers:
                raise Exception('trigger event not find!')
            self.triggers[event][model] = func
            return func
        return wapper


class Model(SQLModel):
    def __repr__(self):
        return '<' + type(self).__name__ + '>' + str(self.id)

    def save(self, auto_commit=True):
        self.db.session.add(self)
        if auto_commit:
            self.db.session.commit()

    def delete(self):
        self.db.session.delete(self)
        self.db.session.commit()

    def commit(self):
        self.db.session.commit()

    def update(self, kwargs):
        for k in kwargs:
            if not hasattr(self.__class__, k):
                continue
            map_class = getattr(self.__class__, k)
            try:
                getattr(map_class, 'mapper')
                map_class = map_class.mapper.entity
                map_entitys = []
                for map_id in kwargs[k]:
                    map_entitys.append(map_class.query.get(map_id))
                setattr(self, k, map_entitys)
            except Exception as ex:
                field = getattr(self.__class__, k)
                field_type = str(field.prop.columns[0].type)
                if field_type.startswith('DATE'):
                    setattr(self, k, ORM.str2datetime(kwargs[k]))
                else:
                    setattr(self, k, kwargs[k])

    def to_dict(self):
        model_dict = dict(self.__dict__)
        for key in self.__dict__:
            attr = getattr(self, key)
            if isinstance(attr, sqlalchemy.orm.collections.InstrumentedList):
                model_dict[key] = ORM.to_dict(getattr(self, key))
            elif isinstance(attr, Model):
                model_dict[key] = getattr(self, key).to_dict()
        del model_dict['_sa_instance_state']
        return model_dict

    def jsonify(self):
        return jsonify(self.to_dict())

    def max(self, col, **where):
        col = getattr(self, col)
        val = self.db.session.query(func.max(col)).filter(where).scalar()
        return val

    login_filter = None