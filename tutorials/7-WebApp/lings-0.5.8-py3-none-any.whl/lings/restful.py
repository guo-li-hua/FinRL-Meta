# -*- coding:utf-8 --*--
import re
import pinyin
from flask import jsonify, views, request, Response, abort
from flask.json import JSONEncoder
from decimal import Decimal
from datetime import datetime, date
from .orm import ORM
from sqlalchemy.sql import text
from werkzeug.exceptions import Unauthorized, Forbidden


class Restful:
    def __init__(self, auth):
        self.app = None
        self.prefix = "/api/"
        self.debug = False
        self.funcs = []
        self.api_desc = dict()
        self.Model = None
        self.auth = auth
        self.triggers = {
            'before_insert': {},
            'after_insert': {},
            'before_delete': {},
            'after_delete': {},
            'before_update': {},
            'after_update': {},
        }

    def init_app(self, app, model):
        self.app = app
        self.prefix = app.config['LINGS_API_PREFIX']
        self.debug = app.config['DEBUG']
        self.Model = model

        class CustomJSONEncoder(JSONEncoder):
            def default(self, obj):
                try:
                    if isinstance(obj, datetime) or isinstance(obj, date):
                        return obj.strftime('%Y-%m-%d %H:%M:%S')
                    elif isinstance(obj, Decimal):
                        return float(obj)
                    elif isinstance(obj, bytes):
                        return str(obj, encoding='utf-8')
                    else:
                        return str(obj)
                except TypeError:
                    pass
                return JSONEncoder.default(self, obj)


        app.json_encoder = CustomJSONEncoder
        self._bind_model(model)

        if not self.debug:
            @app.errorhandler(Exception)
            def err_handler(error):
                status_code = 401 if isinstance(error, Unauthorized) else 500
                return jsonify(dict(code=-1, message=Restful._error_msg(error), data={}, ext={})), status_code

        @app.before_first_request
        def before_first_request():
            if self.debug:
                self._analysis_funcs()

    @property
    def ok(self):
        return jsonify(dict(code=0, message='', data={}, ext={})), 200

    @staticmethod
    def fail(msg, code=500):
        return jsonify(dict(code=-1, message=msg, data={}, ext={})), code

    @staticmethod
    def response(data={}, ext={}, message=''):
        try:
            return jsonify(dict(code=0, message=message, data=data, ext=ext)), 200
        except Exception:
            data = ORM.to_dict(data)
            return jsonify(dict(code=0, message=message, data=data, ext=ext)), 200

    @staticmethod
    def _error_msg(ex):
        if isinstance(ex, Unauthorized):
            return u'未登录系统！'
        if isinstance(ex, Forbidden):
            return u'无访问权限！'
        if len(ex.args) > 0:
            s = ex.args[0]
        elif getattr(ex, 'description'):
            s = ex.description
        else:
            s = ex.message
        return s

    def login_filter(self, c, obj=None):
        query = c.query
        me = self.auth.current_user
        if getattr(c, 'login_filter') is None:
            return query
        for kv in getattr(c, 'login_filter').items():
            login_objs = kv[1] if isinstance(kv[1], list) else [kv[1]]
            for login_obj in login_objs:
                if isinstance(me, login_obj.class_) and hasattr(me, login_obj.key):
                    val = getattr(me, login_obj.key)
                    if val is None:
                        continue
                    if obj is None:
                        query = query.filter(kv[0] == val)
                    elif getattr(obj, kv[0].key) != val:
                        raise Exception('无操作此记录的权限')
        return query

    def _get_model_class(self):
        class_name = request.path.split('/')[2]
        class_name = ''.join(map(lambda s: s.capitalize(), class_name.split('_')))
        c = getattr(self.Model, class_name)
        if c is not None:
            return c
        else:
            raise NameError(class_name)

    def _post(self):
        c = self._get_model_class()
        km = dict()
        for k in request.json:
            if not hasattr(c, k):
                continue
            map_class = getattr(c, k)
            try:
                getattr(map_class, 'mapper')
                map_class = map_class.mapper.entity
                map_entitys = []
                for map_id in request.json[k]:
                    if isinstance(map_id, dict):
                        obj = map_class()
                        obj.update(map_id)
                        obj.save()
                    else:
                        obj = map_class.query.get(map_id)
                    map_entitys.append(obj)
                km[k] = map_entitys
            except Exception as ex:
                field = getattr(c, k)
                field_type = str(field.prop.columns[0].type)
                if field_type.startswith('DATE'):
                    km[k] = ORM.str2datetime(request.json[k])
                else:
                    km[k] = request.json[k] if k != 'pinyin' else pinyin.get_initial(request.json[k], '')
        obj = c(**km)
        self.login_filter(c, obj)
        if c in self.triggers['before_insert']:
            self.triggers['before_insert'][c](obj)
        obj.save()
        if c in self.triggers['after_insert']:
            self.triggers['after_insert'][c](obj)
        return jsonify(dict(code=0, message='', data=obj.to_dict(), ext={}))

    def _get(self, id, attr=None, page_num=None, per_page=20):
        pages = 0
        c = self._get_model_class()
        query = self.login_filter(c)
        if id is None:
            if len(request.args) > 0:
                prex = request.path.split('/')[2] + '.'
                filter_str = ''
                filter_params = dict()
                i = 1
                for arg in request.args:
                    val = request.args[arg]
                    val = val.replace('$', '%')
                    if '.' in arg:
                        field_name = arg.replace('.', '_1.')
                    else:
                        field_name = prex + arg
                    filter_str += field_name
                    if '%' in val:
                        filter_str += ' LIKE :'
                    elif val.startswith('<'):
                        filter_str += '<:'
                        val = val[1:]
                    elif val.startswith('<='):
                        filter_str += '<=:'
                        val = val[2:]
                    elif val.startswith('>'):
                        filter_str += '>:'
                        val = val[1:]
                    elif val.startswith('>='):
                        filter_str += '>=:'
                        val = val[2:]
                    elif val.startswith('<>') or val.startswith('!='):
                        filter_str += '<>:'
                        val = val[2:]
                    else:
                        filter_str += '=:'
                    arg = arg.replace('.', '_') + str(i)
                    filter_str += arg + ' AND '
                    filter_params[arg] = val
                    i += 1
                filter_str = filter_str[:-5]
                filter_str = text(filter_str)
                if page_num is None:
                    rows = query.filter(filter_str).params(filter_params).all()
                    return self.response(ORM.to_dict(rows))
                elif page_num > 0:
                    paginate = query.filter(filter_str).params(filter_params).paginate(page_num, per_page=per_page)
                    rows = paginate.items
                    pages = paginate.pages
                    return self.response(ORM.to_dict(rows), dict(pages=pages, total=paginate.total))
            else:
                if page_num is None:
                    rows = query.all()
                    return self.response(ORM.to_dict(rows))
                elif page_num > 0:
                    paginate = query.paginate(page_num, per_page=per_page)
                    rows = paginate.items
                    pages = paginate.pages
                    return self.response(ORM.to_dict(rows), dict(pages=pages, total=paginate.total))
        else:
            row = query.filter_by(id=id).first()
            if row is None:
                return jsonify(dict(code=0, data={}, ext={}, message='not found!'))
            if attr is None:
                return jsonify(dict(code=0, data=row.to_dict(), ext={}, message=''))
            else:
                rows = getattr(row, attr)
                if hasattr(rows, 'all'):
                    rows = rows.all()
                if isinstance(rows, list):
                    return self.response(ORM.to_dict(rows))
                else:
                    return self.response(rows.to_dict())

    def _delete(self, id):
        c = self._get_model_class()
        obj = c.query.get(id)
        self.login_filter(c, obj)
        if c in self.triggers['before_delete']:
            self.triggers['before_delete'][c](obj)
        obj.delete()
        if c in self.triggers['after_delete']:
            self.triggers['after_delete'][c](obj)
        return jsonify(dict(code=0, message='', data={}, ext={}))

    def _put(self, id):
        c = self._get_model_class()
        query = self.login_filter(c)
        obj = query.filter_by(id=id).first()
        if obj is None:
            raise Exception('更新失败！')
        for k in request.json:
            if not hasattr(c, k):
                continue
            map_class = getattr(c, k)
            try:
                getattr(map_class, 'mapper')
                map_class = map_class.mapper.entity
                map_entitys = []
                for map_id in request.json[k]:
                    map_entitys.append(map_class.query.get(map_id))
                setattr(obj, k, map_entitys)
            except Exception as ex:
                field = getattr(c, k)
                if not hasattr(field.prop, 'columns'):
                    continue
                field_type = str(field.prop.columns[0].type)
                if field_type.startswith('DATE'):
                    setattr(obj, k, ORM.str2datetime(request.json[k]))
                else:
                    setattr(obj, k, request.json[k] if k != 'pinyin' else pinyin.get_initial(request.json[k], ''))
        if c in self.triggers['before_update']:
            self.triggers['before_update'][c](obj)
        obj.commit()
        if c in self.triggers['after_update']:
            self.triggers['after_update'][c](obj)
        return jsonify(dict(code=0, message='', data=obj.to_dict(), ext={}))

    def register_api(self, model, model_desc, url, pk='id', pk_type='int'):
        if model_desc is None:
            model_desc = model
        pos = model_desc.find('\n')
        doc = model_desc
        model_desc = model_desc[:pos + 1] if pos > 0 else model_desc

        endpoint = '_get_' + model + '_list'
        self.api_desc[endpoint] = '读取'+model_desc + '列表'
        self.app.add_url_rule(url, defaults={pk: None}, endpoint=endpoint, view_func=self._get, methods=['GET'])

        endpoint = '_get_' + model + '_page_list'
        self.api_desc[endpoint] = '分页读取'+model_desc + '列表'
        self.app.add_url_rule('%spage/<int:page_num>/<int:per_page>' % url, defaults={pk: None}, endpoint=endpoint,
                              view_func=self._get, methods=['GET'])
        endpoint = '_new_' + model
        self.api_desc[endpoint] = '新建'+doc
        self.app.add_url_rule(url, endpoint=endpoint, view_func=self._post, methods=['POST'])

        endpoint = '_get_' + model
        self.api_desc[endpoint] = '读取'+model_desc + '详细信息'
        self.app.add_url_rule('%s<%s:%s>' % (url, pk_type, pk), endpoint=endpoint, view_func=self._get, methods=['GET'])

        endpoint = '_update_' + model
        self.api_desc[endpoint] = '修改'+model_desc
        self.app.add_url_rule('%s<%s:%s>' % (url, pk_type, pk), endpoint=endpoint, view_func=self._put, methods=['PUT'])

        endpoint = '_delete_' + model
        self.api_desc[endpoint] = '删除'+model_desc
        self.app.add_url_rule('%s<%s:%s>' % (url, pk_type, pk), endpoint=endpoint, view_func=self._delete,
                              methods=['DELETE'])

        endpoint = '_get_' + model + '_attr'
        self.api_desc[endpoint] = '读取'+model_desc + '的属性列表'
        self.app.add_url_rule('%s<%s:%s>/<%s>' % (url, pk_type, pk, 'attr'), endpoint=endpoint, view_func=self._get,
                              methods=['GET'])

    def _bind_model(self, model):
        for c in dir(model):
            x = getattr(model, c)
            if 'query' in dir(x):
                c = '_'.join(map(lambda s: s.lower(), re.findall('[A-Z][a-z]*', c)))
                self.register_api(c, x.__doc__, self.prefix + c + '/', pk='id')

    def load_tree(self, class_name, region_id=None):
        c = getattr(self.Model, class_name) if isinstance(class_name, str) else class_name
        return_node = []
        ret = dict()
        ret[0] = {'id': 0, 'title': u'Tree', 'expand': True, 'children': []}
        query = self.login_filter(c)
        nodes = query.all()
        for node in nodes:
            ret[node.id] = node.to_dict()
            ret[node.id]['title'] = ret[node.id]['name']
            ret[node.id]['label'] = ret[node.id]['name']
            ret[node.id]['value'] = ret[node.id]['id']
            if region_id is not None:
                if node.id == region_id:
                    return_node.append(ret[node.id])
            if node.pid in ret:
                if 'children' not in ret[node.pid]:
                    ret[node.pid]['children'] = []
                ret[node.pid]['children'].append(ret[node.id])
        if region_id is None:
            return ret[0]['children']
        else:
            return return_node

    def trigger(self, event, model):
        def wapper(func):
            if event not in self.triggers:
                raise Exception('trigger event not find!')
            self.triggers[event][model] = func
            return func
        return wapper

    def _analysis_funcs(self):
        funcs = self.app.view_functions
        for x in funcs:
            if x != 'static':
                maps = self.app.url_map.iter_rules(x)
                doc = funcs[x].__doc__
                if x in self.api_desc:
                    doc = self.api_desc[x]
                f = dict()
                f['endpoint'] = x
                doc = '' if doc is None else doc
                pos = doc.find('\n')
                f['desc'] = doc[:pos+1] if pos > 0 else doc
                f['doc'] = doc
                for m in maps:
                    if 'HEAD' in m.methods:
                        m.methods.remove('HEAD')
                    if 'OPTIONS' in m.methods:
                        m.methods.remove('OPTIONS')
                    f['url'] = m.rule
                    f['method'] = list(m.methods)
                self.funcs.append(f)
        self.funcs.sort(key = lambda p: p['url'])



