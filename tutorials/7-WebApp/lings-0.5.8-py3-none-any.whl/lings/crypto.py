# -*- coding:utf-8 --*--
import os
import pickle
import re
import copy
import base64
from flask import jsonify,request
from rsa import PublicKey, verify
from datetime import datetime


class Crypto:
    def __init__(self, app):
        self.__license = {'organization':'Anonymous','expire':'1900-01-01','bid':'','signature':''}
        self.load_license()
        self.pk = '-----BEGIN RSA PUBLIC KEY-----\nMEgCQQCV8NLanbIs2HVyFTlZdfiu48Me/OG2+b0GYxiPGpB2LxD9pIiAyc+ZHKXB\nDIOl67nFZYDaoXl006Jzj19unN6FAgMBAAE=\n-----END RSA PUBLIC KEY-----\n'
        self.__pubk__ = PublicKey.load_pkcs1(self.pk)
        if not self.self_test():
            self.__pubk__ = None
            raise FileNotFoundError
        @app.route('/api/reg_key')
        def reg_key():
            return jsonify({'code':0, 'data':self.bid()})

        @app.route('/api/license')
        def license():
            l = copy.deepcopy(self.__license)
            l['signature'] = base64.encodebytes(l['signature'])
            return jsonify({'code':0, 'data':l})

        @app.route('/api/save_license', methods=['POST'])
        def save_license():
            for f in request.files:
                request.files[f].save('lactive.pyd')
                self.load_license()
                return jsonify({'code':0})
            return jsonify({'code':500, 'msg':u'证书保存失败'})

    def bid(self):
        if os.name == 'nt':
            os.environ['PATH'] += '%SystemRoot%\\system32\\wbem'
            f = os.popen('wmic bios get serialnumber')
            s = re.findall('\w+', f.read())[1]
            f.close()
            f = os.popen('wmic CPU get ProcessorID')
            s += f.read()
            f.close()
            f = os.popen('wmic diskdrive where index=0 get SerialNumber')
            s += re.findall('\w+', f.read())[1]
            f.close()
        else:
            f = os.popen('dmidecode -t 1')
            s = re.findall('UUID: \S+', f.read())[0]
            s = s[6:].replace('-','').upper()
            f.close()
        return self.baseN(abs(hash(s)), 36)

    def baseN(self, num, b):
        return ((num == 0) and "0") or (
                    self.baseN(num // b, b).lstrip("0") + "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"[num % b])

    def load_license(self):
        try:
            with open('lactive.pyd', 'rb') as f:
                self.__license = pickle.load(f)
            self.__license['bid'] = self.bid()
        except Exception:
            pass

    def license_verify(self):
        s = self.__license['organization']
        s += self.__license['bid']
        s += self.__license['expire'].strftime('%Y%m%d')
        s = s.encode('utf-8')
        if (datetime.now() - self.__license['expire']).total_seconds()>0:
            return {'msg': u'授权码已过期，请激活软件！', 'code': 500}
        try:
            verify(s, self.__license['signature'], self.__pubk__)
        except Exception as ex:
            return {'msg': u'授权码无效，请激活软件！', 'code': 500}
        return {'code': 0}

    def self_test(self):
        s = b'3{o\x82\xbbq\xff\x9e\xf1{\xde{\xdeP\x96\xba\x0e\x0f\xca\xca\x1dZ-\xcd\xe6\x8c\xbc\xfa\x1a\xa1\x97/F\xe4\xf9|9S\t0e\xa7\xc2\xe4\xb8y\x8e\x9f\xf5p\x03\xa8\x13\xd7y\xc3\x8eg\x1d9\xd7,\xfa\xdd'
        return verify(self.pk.encode('utf-8'), s, self.__pubk__) == 'SHA-1'
