# -*- coding:utf-8 --*--
from flask import request, session, abort, jsonify
from datetime import datetime, timedelta
import pickle
import uuid
import os
import json


class Auth:
    def __init__(self):
        self._app = None
        self.debug = False
        self._endpoints = dict()
        self._users = dict()
        self._last_clean_time = datetime.now()
        self.redis = None

    def init_app(self, app):
        self._app = app
        self.debug = app.config['DEBUG']

        # 加载endpoints权限配置字典
        if os.path.exists('endpoints.json'):
            with open('endpoints.json', 'rb') as fp:
                self._endpoints = json.load(fp)

        url = app.config['LINGS_AUTH_URL']
        if url is not None:
            import redis, urllib
            url = urllib.parse.urlparse(url)
            if url.scheme != 'redis':
                raise Exception('只支持Redis或内存保存认证信息（url=None）')
            db = 0 if url.path[1:] == '' else int(url.path[1:])
            self.redis = redis.Redis(host=url.hostname, port=6379 if url.port is None else url.port,
                                     db=db, password=url.password)

        if not self.debug:
            @app.before_request
            def before_request():
                if not request.path.startswith('/api/') or '/_' in request.path:
                    return
                if 'Authorization' not in request.headers and 'token' not in session:
                    abort(401)
                token = session['token'] if 'token' in session else request.headers['Authorization']
                user = self.get_kv(token)
                if user is None:
                    session.clear()
                    abort(401)
                if '*' in user['endpoints'] or request.endpoint in user['endpoints']:
                    self.set_expire(token, user['expire'])
                    self.set_expire(user['user_app_id'], user['expire'])
                else:
                    abort(403)
        else:
            @app.route('/api/_endpoint', methods=['GET'])
            def get_endpoints():
                """读取endpoints"""
                return jsonify(self._endpoints)

            @app.route('/api/_endpoint', methods=['POST'])
            def save_endpoints():
                """保存endpoints"""
                self._endpoints = request.json
                with open('endpoints.json', 'wb+'):
                    json.dump(self._endpoints, fp)
                return jsonify({'code': 0})

    def has_permission(self, access_item):
        if access_item in self.current_user['access']:
            return True
        else:
            return False

    @property
    def current_user(self):
        if 'Authorization' not in request.headers and 'token' not in session:
            abort(401)
        token = session['token'] if 'token' in session else request.headers['Authorization']
        obj = self.get_kv(token)
        if obj is not None:
            return obj['user_obj']
        else:
            return None

    def get_user(self, token):
        obj = self.get_kv(token)
        if obj is not None:
            return obj['user_obj']
        else:
            abort(401)

    def set_expire(self, k, expire_minutes):
        if self.redis is None:
            user = self._users[k]
            if 'act_time' in user:
                if (datetime.now() - user['act_time']).total_seconds() > expire_minutes * 60:
                    session.clear()
                    abort(401)
                user['act_time'] = datetime.now()
        else:
            self.redis.expire(k, expire_minutes * 60)

    def get_kv(self, k):
        if self.redis is None:
            if k in self._users:
                return self._users[k]
        else:
            s = self.redis.get(k)
            if s is not None:
                return pickle.loads(s)
        return None

    def set_kv(self, k, v, expire_minutes):
        if self.redis is None:
            self._users[k] = v
        else:
            self.redis.set(k, pickle.dumps(v), ex=expire_minutes*60)

    def rm_kv(self, k):
        if self.redis is None:
            if k in self._users:
                del self._users[k]
        else:
            self.redis.delete(k)

    def login(self, user_obj, app_name='web', menu=['*'], expire_minutes=24*60):
        user_app_id = app_name + str(user_obj.id)
        old_token = self.get_kv(user_app_id)
        if old_token is not None:
            self.rm_kv(old_token)
        expire_minutes = self._app.config['LINGS_AUTH_EXPIRE'] or expire_minutes
        endpoints = self.parse_menu(menu)
        token = uuid.uuid4().hex
        val = dict(user_obj=user_obj, endpoints=endpoints, act_time=datetime.now(), expire=expire_minutes, user_app_id=user_app_id)
        self.set_kv(token, val, expire_minutes)
        self.set_kv(user_app_id, token, expire_minutes)
        session['token'] = token
        self._clean_login()
        return token

    def logout(self):
        if 'Authorization' not in request.headers and 'token' not in session:
            abort(401)
        token = session['token'] if 'token' in session else request.headers['Authorization']
        login_obj = self.get_kv(token)
        if login_obj is not None:
            user_app_id = login_obj['user_app_id']
            self.rm_kv(user_app_id)
        self.rm_kv(token)
        session.clear()
        return token

    def _clean_login(self):
        if self.redis is not None:
            return
        if (datetime.now() - self._last_clean_time).total_seconds() < 86400:
            return
        self._last_clean_time = datetime.now()
        users = []
        for user in self._users:
            if (datetime.now() - self._users[user]['act_time']).total_seconds() > self._users[user]['expire']*60:
                users.append(user)
        for u in users:
            self._users.pop(u)

    def parse_menu(self, menu_access):
        endpoints = set()
        if '*' in menu_access:
            return set(list('*'))
        for m in menu_access:
            endpoints |= self._endpoints[m]
        return endpoints

